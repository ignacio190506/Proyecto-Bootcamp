/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package clases_trabajo;

/**
 *
 * @author ignac
 */
public interface Interface {
    
    int MASAATOMICAO = 16;
    int MASAATOMICAN = 14;
    int MASAATOMICAS = 32;
    int MASAATOMICASO2 = MASAATOMICAS + MASAATOMICAO * 2;
    int MASAATOMICANO2 = MASAATOMICAN + MASAATOMICAO *2;
    int MASAATOMICAO3 = MASAATOMICAO * 3;
}
